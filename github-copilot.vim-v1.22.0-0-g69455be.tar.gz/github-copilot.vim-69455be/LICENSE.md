GitHub Copilot is offered under the [GitHub Terms of
Service](https://docs.github.com/en/site-policy/github-terms/github-terms-for-additional-products-and-features#github-copilot).

Copyright (C) 2023 GitHub, Inc. - All Rights Reserved.
